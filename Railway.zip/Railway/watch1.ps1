# ============================================
# Railway - Tomcat Java Servlet Auto Watcher
# ============================================

$project = "C:\Users\WELCOME\Documents\Java Class\Railway"
$tomcat = "C:\Program Files\Apache Software Foundation\Tomcat 10.1_Tomcat10.1.59"

# --------------------------------------------
# Java / Tomcat environment
# --------------------------------------------

$env:JAVA_HOME = "C:\Program Files\Java\jdk-26.0.1"
$env:CATALINA_HOME = $tomcat

# --------------------------------------------
# Project directories
# --------------------------------------------

$src = "$project\src"
$web = "$project\web"
$classes = "$web\WEB-INF\classes"

# Tomcat application directory
$tomcatApp = "$tomcat\webapps\Railway"

# --------------------------------------------
# Create required directories
# --------------------------------------------

Write-Host "Checking directories..."

New-Item -ItemType Directory -Force -Path $web | Out-Null
New-Item -ItemType Directory -Force -Path "$web\WEB-INF" | Out-Null
New-Item -ItemType Directory -Force -Path $classes | Out-Null
New-Item -ItemType Directory -Force -Path $tomcatApp | Out-Null

Write-Host "Directories ready."
Write-Host ""

# --------------------------------------------
# Stop old Tomcat instance
# --------------------------------------------

Write-Host "Stopping existing Tomcat..."

& "$tomcat\bin\shutdown.bat"

Start-Sleep -Seconds 3

# --------------------------------------------
# Start Tomcat
# --------------------------------------------

Write-Host "Starting Tomcat..."

& "$tomcat\bin\startup.bat"

Start-Sleep -Seconds 5

# --------------------------------------------
# Find Java source files
# --------------------------------------------

Write-Host ""
Write-Host "Finding Java files..."

$javaFiles = Get-ChildItem $src -Filter "*.java" -Recurse |
    ForEach-Object { $_.FullName }

if ($javaFiles.Count -eq 0) {

    Write-Host "No Java files found." -ForegroundColor Red
    exit
}

Write-Host "Found $($javaFiles.Count) Java file(s)."
Write-Host ""

# --------------------------------------------
# Compile Java files
# --------------------------------------------

function Compile-Java {

    Write-Host "Compiling Java files..."

    # Remove old compiled classes
    if (Test-Path $classes) {
        Remove-Item "$classes\*" -Recurse -Force -ErrorAction SilentlyContinue
    }

    # Find Java files again
    $javaFiles = Get-ChildItem $src -Filter "*.java" -Recurse |
        ForEach-Object { $_.FullName }

    javac `
        -cp "$project\servlet-api.jar" `
        -d "$classes" `
        $javaFiles

    if ($LASTEXITCODE -ne 0) {

        Write-Host ""
        Write-Host "Compilation FAILED." -ForegroundColor Red
        return $false
    }

    Write-Host "Compilation successful." -ForegroundColor Green

    return $true
}

# --------------------------------------------
# Deploy application
# --------------------------------------------

function Deploy-App {

    Write-Host ""
    Write-Host "Deploying application..."

    # Make sure Tomcat application directory exists
    New-Item -ItemType Directory -Force -Path $tomcatApp | Out-Null

    # Copy web application files
    Copy-Item `
        -Path "$web\*" `
        -Destination $tomcatApp `
        -Recurse `
        -Force

    Write-Host "Deployment successful." -ForegroundColor Green
}

# --------------------------------------------
# Initial compilation
# --------------------------------------------

if (!(Compile-Java)) {
    exit
}

# --------------------------------------------
# Initial deployment
# --------------------------------------------

Deploy-App

Write-Host ""
Write-Host "============================================"
Write-Host "Railway application is running"
Write-Host "============================================"
Write-Host ""
Write-Host "Open:"
Write-Host "http://localhost:8080/Railway/employeePreference.html"
Write-Host ""
Write-Host "Servlet:"
Write-Host "http://localhost:8080/Railway/savePreference"
Write-Host ""
Write-Host "View Preferences:"
Write-Host "http://localhost:8080/Railway/viewPreference"
Write-Host ""
Write-Host "Watching:"
Write-Host $src
Write-Host ""
Write-Host "Press Ctrl+C to stop."
Write-Host "============================================"
Write-Host ""

# --------------------------------------------
# Store initial file timestamps
# --------------------------------------------

$lastWrite = @{}

$javaFiles = Get-ChildItem $src -Filter "*.java" -Recurse

foreach ($file in $javaFiles) {

    $lastWrite[$file.FullName] = $file.LastWriteTimeUtc
}

# --------------------------------------------
# Watch for Java changes
# --------------------------------------------

while ($true) {

    Start-Sleep -Milliseconds 500

    $files = Get-ChildItem $src -Filter "*.java" -Recurse

    $changed = $false

    foreach ($file in $files) {

        $time = $file.LastWriteTimeUtc

        # New Java file
        if (!$lastWrite.ContainsKey($file.FullName)) {

            $lastWrite[$file.FullName] = $time

            Write-Host ""
            Write-Host "New Java file detected: $($file.Name)" `
                -ForegroundColor Yellow

            $changed = $true

            continue
        }

        # Existing Java file changed
        if ($lastWrite[$file.FullName] -ne $time) {

            $lastWrite[$file.FullName] = $time

            Write-Host ""
            Write-Host "Java file changed: $($file.Name)" `
                -ForegroundColor Yellow

            $changed = $true
        }
    }

    # ----------------------------------------
    # Recompile and deploy
    # ----------------------------------------

    if ($changed) {

        Write-Host ""
        Write-Host "============================================"
        Write-Host "Change detected"
        Write-Host "============================================"

        if (Compile-Java) {

            Deploy-App

            Write-Host ""
            Write-Host "Application updated successfully." `
                -ForegroundColor Green

            Write-Host "Open:"
            Write-Host "http://localhost:8080/Railway/employeePreference.html"
            Write-Host ""
        }
        else {

            Write-Host ""
            Write-Host "Deployment skipped because compilation failed." `
                -ForegroundColor Red
            Write-Host ""
        }
    }
}

